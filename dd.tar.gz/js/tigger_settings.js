// Specify Web Services
// I've stored the capabilities document as we cannot get the EUMETVIEW by jscript due to EUMETVIEW server
// not allowing CORS (NASA GIBS does). Also, fetching the document via cgi script fails with
// an inability to connect (though running the script standalone does work...)
var webServices = {
    'Tigger': {
        name: 'Tigger',
        capabilitiesURL: 'getCapabilities.xml',
        endpointURL: 'wmts.cgi',
        type: 'wmts'
    },
    'NASA': {
        name: 'NASA',
        capabilitiesURL: 'conf/NASA_GIBS_WMTS_GEO_CAPABILITIES.xml',
        endpointURL: 'https://gibs.earthdata.nasa.gov/wmts/epsg4326/best/wmts.cgi?',
        type: 'wmts'
    },
    'EView': {
        name: 'EView',
        capabilitiesURL: 'conf/EUMETVIEW_WMS_CAPABILITIES.xml',
        endpointURL: 'http://eumetview.eumetsat.int/geoserver/wms',
        type: 'wms',
        serverType: 'geoserver'
    }
};


// Map views
var mapViews = {
    'UKEuro': {
        center: [0, 50],
        zoom: 5
    },
    'MiddleEast': {
        center: [50, 30],
        zoom: 5
    },
    'Falklands': {
        center: [-60, -50],
        zoom: 5
    }
};


// Predefined layer groups
var layerGroups = {
    'Convection': [
        'EViewmeteosat_msg_convection',
        'EViewmeteosat_msg_cth',
        'EViewmeteosat_msg_mpe',
        'EViewmeteosat_msg_ir108'
     ],
    'Dust': [
        'EViewmeteosat_msg_dust',
        'EViewmeteosat_msg_ash',
        'EViewmeteosat_msg_eview',
        'EViewmeteosat_msg_natural'
    ]
};
