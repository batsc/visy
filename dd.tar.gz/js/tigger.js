// Global vars
var maps = [],
    availableLayers = {},
    datetime_global;


// Set projection
var EPSGProjection = "EPSG:4326";
var mapProjection = ol.proj.get(EPSGProjection);


$(document).ready(function() {

    // Set map view functionality
    $('.setMapView').each(function() {
        var region = $(this).attr('id');
        $(this).click(function() {
            maps.forEach(function(map) {
                map.getView().setZoom(mapViews[region].zoom);
                map.getView().setCenter(mapViews[region].center);
            });
        });
    });

    // Set tiled view functionality
    $('.setTiledView').each(function() {
        var button = $(this);
        button.click(function() {
            if (! button.hasClass('disabled')) {
                $('.setTiledView').each(function() {
                    $(this).removeClass('disabled')
                });
                button.addClass('disabled');

                // Get the num cols and rows from the ID
                var buttonId = button.attr('id');
                var re = /col(\d+)row(\d+)/i;
                var dims = re.exec(buttonId);
                var ncol = dims[1],
                    nrow = dims[2];

                // Update maps display
                updateMapsLayout(ncol, nrow);
            }
        });
    });

    // Enable functionality to add external Web Service layers
    $('.addWS').each(function() {
        var button = $(this);
        button.click(function() {
            if (button.hasClass('active')) {
                button.removeClass('active');
                removeFromAvailableLayers(button.attr('id'));
            } else {
                button.addClass('active');
                addToAvailableLayers(webServices[button.attr('id')]);
            }
        });
    });

    // Enable functionality to display pre-defined groups of layers
    $('.setLayerGroup').each(function() {
        $(this).click(function() {
            var key = $(this).attr('id').replace('layerGroup', '');
            layerGroups[key].forEach(function(layerName) {
                if (layerName in availableLayers) {
                    if (availableLayers[layerName].displayedInMap < 0) {
                        $('#availableLayer' + layerName).click();
                    }
                }
            });
        });
    });

    // Functionality to search available layers on input
    $('#availableLayersSearch').on('input', function() {
        var layersToShow = [];
        var layersToHide = [];

        for (var layerId in availableLayers) {
            if (availableLayers[layerId].title.toLowerCase().indexOf($(this).val().toLowerCase())
                === -1) {
                layersToHide.push(layerId);
            }
            else {
                layersToShow.push(layerId);
            }
        }

        // Hide/show layers
        for (var i = 0; i < layersToShow.length; i++) {
            $('#availableLayer' + layersToShow[i]).css('display', 'inherit');
        }
        for (var i = 0; i < layersToHide.length; i++) {
            $('#availableLayer' + layersToHide[i]).css('display', 'none');
        }
    });

    // Time
    var d = new Date();
    // Round down time to nearest 15 minutes, then subtract 15 minutes
    // to allow time for MSG image to be produced
    datetime_global = new Date(d.getTime() - d.getTime() % (15 * 60 * 1000) - (15 * 60 * 1000));
    $("#datetime").val(datetime_global.toISOString());

    // Update the global datetime on return keypress of datetime input field
    $("#datetime").keypress(function(e) {
        if (e.which == 13) {
            // Update time (should check it first)
            datetime_global = new Date($(this).val());
            updateLayerTime(datetime_global);
        }
    });

    // Add the Tigger Web Services layers
    addToAvailableLayers(webServices['Tigger']);

    // Add an initial map
    updateMapsLayout();

    // Add sidebar
    var sidebar = new ol.control.Sidebar({element: 'sidebar', position: 'left'});
    maps[0].addControl(sidebar);
});


function updateMapsLayout(ncol=1, nrow=1) {

    var mapIndex = 0;
    for (var j = 0; j < nrow; j++) {
        for (var i = 0; i < ncol; i++) {
            var mapId = "map_" + parseInt(mapIndex);

            // If this is the first map, set the initial view
            var view;
            if (maps.length == 0) {
                view = new ol.View({
                           projection: EPSGProjection,
                           center: [0, 30],
                           zoom: 4
                       });
            } else {
                view = maps[0].getView();
            }

            // Add new map if this index doesn't exist
            if (mapIndex > (maps.length - 1)) {
                var mapDiv = $('<div id="' + mapId + '" class="map"></div>');
                // Add a displayed layer list div
                var DLL = $('<div class="list-group displayedLayersList overflow_auto"' +
                            'id="displayedLayersList' + mapIndex + '">' +
                            '<ul id="sortable' + mapIndex +
                            '" class="sortableDLL"></ul></div>');
                mapDiv.append(DLL);
                $('#map_container').append(mapDiv);

                // Set up sortable rows for the displayed layer list
                setupSortableDLL(mapIndex);

                // Add a map
                maps.push(new ol.Map({
                    logo: false,
                    controls: ol.control.defaults().extend([
                        new ol.control.ScaleLine({units: 'degrees'})
                    ]),
                    target: mapId,
                    view: view,
                    layers: [
                        new ol.layer.Tile({
                            source: new ol.source.Stamen({layer: 'toner-background'})
                        })
                    ]
                }));

                // If there is more than one layer in map_0, take the
                // one under the top one and assign it to this map
                var numLayersMap0 = maps[0].getLayers().getLength();
                // Assume 1 base map
                if (numLayersMap0 > 2 && mapIndex > 0) {
                    // Layer under top one is at array index = length - 2
                    var movedLayer = maps[0].getLayers().removeAt(numLayersMap0 - 2);
                    maps[mapIndex].getLayers().push(movedLayer);

                    var key = movedLayer.getProperties().service +
                              movedLayer.getProperties().layer_id;
                    availableLayers[key].displayedInMap = mapIndex;

                    // Move the displayed layer list element
                    var DLLE = $('#displayedLayer' + key).parent().detach();
                    $('#sortable' + mapIndex).prepend(DLLE);
                }
            }

            // Set map div size (could use grid box in future browsers)
            var newWidth = 100 / nrow,
                newHeight = 100 / ncol;
            $('#' + mapId).css({
                "width": newWidth.toString() + "%",
                "height": newHeight.toString() + "%"
            });

            // Redraw map
            maps[mapIndex].updateSize();

            mapIndex++;
        }
    };

    // If there were previously too many maps, remove the rest
    if (mapIndex < (maps.length - 1)) {
        var numMaps = maps.length - 1;
        for (var k = numMaps; k >= mapIndex; k--) {
            var map = maps.pop();

            // First set any displayed layers to map_0
            // Assume 1 basemap
            var newMapIndex = 0;
            var numLayers = map.getLayers().getLength() - 1;
            for (var i = numLayers; i > 0; i--) {
                var movedLayer = map.getLayers().pop();
                var newPos = maps[newMapIndex].getLayers().getLength() - 1;
                maps[newMapIndex].getLayers().insertAt(newPos, movedLayer);

                var key = movedLayer.getProperties().service +
                          movedLayer.getProperties().layer_id;
                availableLayers[key].displayedInMap = newMapIndex;

                // Move the displayed layer list element
                var DLLE = $('#displayedLayer' + key).parent().detach();
                $('#sortable' + newMapIndex).children().first().after(DLLE);
            }

            map.setTarget(null);
            $('#map_container > .map').last().remove();
        }
    }
}


function setupSortableDLL(mapIndex) {

    // Set up sortable rows for the displayed layer list
    // for the specified map
    var movedLayer;
    $("#sortable" + mapIndex).sortable({
        axis: 'y',
        containment: 'parent',
        cursor: 'move',
        opacity: 0.75,
        start: function(event, ui) {
            // Get original position
            var oldPos = maps[mapIndex].getLayers().getLength() - ui.item.index() - 1; // Account for 1 base layer
            movedLayer = maps[mapIndex].getLayers().removeAt(oldPos);
        },
        stop: function(event, ui) {
            // Reorder the corresponding map layer appropriately
            var newPos = maps[mapIndex].getLayers().getLength() - ui.item.index(); // Account for 1 base layer
            maps[mapIndex].getLayers().insertAt(newPos, movedLayer);
        }
    });
}


function addToAvailableLayers(webService) {

    // Get the web service capabilities, create layers and store them
    $.ajax({
        url: webService.capabilitiesURL,
        type: 'GET',
        success: function( capabilities ) {
            var layers = layersFromCapabilities(webService, capabilities);

            for (var i = 0; i < layers.length; i++) {
                var key = webService.name + layers[i].getProperties().layer_id;
                availableLayers[key] = {
                    layer: layers[i],
                    title: layers[i].getProperties().title,
                    displayedInMap: -1
                };

                var LLE = new LayerListElement( layers[i].getProperties().layer_id, layers[i] );
                $('#availableLayersList').append( LLE.layerElement );
            }
        },
        error: function() {
            console.log( "Problems" );
        }
    });
}


function removeFromAvailableLayers(webServiceName) {

    // Remove all webServiceName layers from availability
    for (var layerId in availableLayers) {
        if (layerId.includes(webServiceName)) {
            // If displayed, remove layer from map
            var mapIndex = availableLayers[layerId].displayedInMap;
            if (mapIndex >= 0) {
                maps[mapIndex].removeLayer(availableLayers[layerId].layer);
                availableLayers[layerId].displayedInMap = -1;

                // Remove displayed layer list element
                $('#displayedLayer' + layerId).parent().remove();
            }
            delete availableLayers[layerId];
            $('#availableLayer' + layerId).remove();
        }
    }
}


function layersFromCapabilities(webService, capabilities) {

    var OL_layers = [],
        WMTS,
        parser,
        result,
        layers,
        tileMatrixSets,
        mapMetersPerUnit;

    // Use WMS if not WMTS
    WMTS = webService.type == 'wmts' ? true : false;

    // Use OpenLayers to parse capabilities
    parser = WMTS ? new ol.format.WMTSCapabilities() : new ol.format.WMSCapabilities();
    result = parser.read(capabilities);
    layers = WMTS ? result.Contents.Layer : result.Capability.Layer.Layer;

    if (WMTS) {
        tileMatrixSets = result.Contents.TileMatrixSet;
        mapMetersPerUnit = mapProjection.getMetersPerUnit();
    }

    layers.forEach(function (layer) {
        var newLayer;
        if (WMTS) {
            newLayer = layerFromWMTS(webService, layer, tileMatrixSets, mapMetersPerUnit);
        } else {
            newLayer = layerFromWMS(webService, layer);
        }
        if (typeof newLayer != 'undefined') {
            OL_layers.push(newLayer);
        }
    })

    return OL_layers;
}


function layerFromWMS(webService, layer) {
    var newLayer;

    // Only keep layers in the map projection
    for (var i = 0; i < layer.BoundingBox.length; i++) {
        var BB = layer.BoundingBox[i];

        if (BB.crs == EPSGProjection) {
            // Define WMS layer source
            var newLayerSource = new ol.source.ImageWMS({
                url: webService.endpointURL,
                params: {'LAYERS': layer.Name},
                serverType: webService.serverType
            });

            // Remove any colons from the identifier and replace with '_'
            // for search results
            layer.Name = layer.Name.replace(/:/g, '_');

            newLayer = new ol.layer.Image({
                extent: BB.extent,
                source: newLayerSource,
                title: layer.Title,
                layer_id: layer.Name,
                service: webService.name
            });

            // Set the layer (assumes only 1)
            break;
        }
    }

    return newLayer;
}


function layerFromWMTS(webService, layer, tileMatrixSets, mapMetersPerUnit) {
    var tileMatrixSet,
        tileMatrixIds = [],
        resolutions = [];
    /*
    Ideally, this would use ol.source.WMTS.optionsFromCapabilities to
    generate the layer source from getCapabilities, but as of now, it only
    supports TileMatrixSets with names that correspond exactly to the 2
    projections it natively supports. So we have to parse the options and
    calculate the resolutions manually.
    */
    for (var j = 0; j < tileMatrixSets.length; j++) {
        if (tileMatrixSets[j].Identifier == layer.TileMatrixSetLink[0].TileMatrixSet) {
            tileMatrixSet = tileMatrixSets[j];
            for (var k = 0; k < tileMatrixSet.TileMatrix.length; k++) {
                tileMatrixIds.push(tileMatrixSet.TileMatrix[k].Identifier);
                resolutions.push(tileMatrixSet.TileMatrix[k].ScaleDenominator * 0.28E-3 /
                                 mapMetersPerUnit);
            }
        }
    }

    // Remove any full stops from the identifier and replace with 'pt'
    // for search results
    layer.Identifier = layer.Identifier.replace(/\./g, 'pt');

    // Define WMTS layer source
    var newLayerSource = new ol.source.WMTS({
        url: webService.endpointURL,
        layer: layer.Identifier,
        format: layer.Format[0],
        matrixSet: layer.TileMatrixSetLink[0].TileMatrixSet,
        tileGrid: new ol.tilegrid.WMTS({
            origin: [tileMatrixSet.TileMatrix[0].TopLeftCorner[0],
                     tileMatrixSet.TileMatrix[0].TopLeftCorner[1]],
            matrixIds: tileMatrixIds,
            tileSize: tileMatrixSet.TileMatrix[0].TileHeight,
            resolutions: resolutions
        })
    });

    var newLayer = new ol.layer.Tile({
        source: newLayerSource,
        title: layer.Title,
        layer_id: layer.Identifier,
        service: webService.name
    });

    return newLayer;
}


function updateLayerTime(datetime) {

    // Update time of all displayed layers
    var dt = datetime.toISOString().replace(".000", "");
    var layers = maps[0].getLayers().getArray();
    for (var layer in layers) {
        // Check if we can update time dimension first for this layer
        if (typeof layers[layer].getSource().updateDimensions == 'function') {
            layers[layer].getSource().updateDimensions({'TIME': dt});
        }
        else if (typeof layers[layer].getSource().updateParams == 'function') {
            layers[layer].getSource().updateParams({'TIME': dt});
        }
    }
}


function LayerListElement(layerName, layer) {
    this.layer = layer;
    this.layerName = layerName;
    this.title = layer.getProperties().title;
    this.service = layer.getProperties().service;
    this.layerId = this.service + this.layerName;

    this.layerElement = $(
        '<a id="availableLayer' + this.layerId +
        '" href="#" class="list-group-item list-group-item-action flex-column align-items-start">' +
        '<div class="d-flex w-100 justify-content-between">' +
        '<h5 class="mb-1">' + this.title + '</h5>' +
        '<small>' + this.service + ' / ' + this.layerName + '</small>' +
        '</div>' +
        '</a>'
    );

    //  Functionality on mouse click
    var LLE = this;
    $(LLE.layerElement).click(function() {
        if ($(this).hasClass('active')) {
            $(this).removeClass('active');

            // Remove the layer from the map and displayed layer element
            var mapIndex = availableLayers[LLE.layerId].displayedInMap;
            maps[mapIndex].removeLayer(LLE.layer);
            $('#displayedLayersList' + mapIndex)
                 .find('#displayedLayer' + LLE.layerId).parent().remove();
            availableLayers[LLE.layerId].displayedInMap = -1;
        }
        else {
            $(this).addClass('active');

            // Create an entry in the displayed layers list
            var DLLE = new DisplayedLayerListElement(LLE.layerName, LLE.layer);

            // Default to map 0
            var mapIndex = 0;
            $('#displayedLayersList' + mapIndex + ' > ul').prepend(DLLE.layerElement);

            // Set the time parameter to current global datetime value
            // The below is already in a function above - really it should be
            // made a method of a WMTS layer (update time)
            var dt = datetime_global.toISOString().replace(".000", "");
            // Check how to update the time parameter
            if (typeof LLE.layer.getSource().updateDimensions == 'function') {
                LLE.layer.getSource().updateDimensions({'TIME': dt});
            }
            else if (typeof LLE.layer.getSource().updateParams == 'function') {
                LLE.layer.getSource().updateParams({'TIME': dt});
            }

            // Add the layer to the map
            availableLayers[LLE.layerId].displayedInMap = mapIndex;
            maps[mapIndex].addLayer(LLE.layer);
            LLE.layer.setOpacity(1);
        }
    });
}


function DisplayedLayerListElement(layerName, layer) {
    this.layer = layer;
    this.layerName = layerName;
    this.title = layer.getProperties().title;
    this.service = layer.getProperties().service;
    this.layerId = this.service + this.layerName;

    this.layerElement = $(
        '<li class="ui-state-default">' +
        '<a id="displayedLayer' + this.layerId +
        '" href="#" class="list-group-item list-group-item-action flex-column align-items-start visible">' +
        '<div class="d-flex w-100 justify-content-between">' +
        '<div class="btn-group" role="group">' +
        '</div>' +
        '<h5 class="mb-1">' + this.title + '</h5>' +
        '<small>' + this.service + ' / ' + this.layerName + '</small>' +
        '</div>' +
        '</a>' +
        '</li>'
    );

    var DLLE = this;

    // Add a remove layer button
    var rmLayer = $(
        '<button class="btn btn-default" type="button"><span class="glyphicon glyphicon-remove"></span></button>'
    );
    rmLayer.click(function() {
        DLLE.layerElement.remove();
        $('#availableLayersList')
            .find('#availableLayer' + DLLE.layerId).removeClass('active');
        var mapIndex = availableLayers[DLLE.layerId].displayedInMap;
        maps[mapIndex].removeLayer(DLLE.layer);
        availableLayers[DLLE.layerId].displayedInMap = -1;
    });

    // Add a visiblity toggle button
    var toggleLayer = $(
        '<button class="btn btn-default" type="button"><span class="glyphicon glyphicon-eye-open"></span></button>'
    );
    toggleLayer.click(function() {
        if ($('#displayedLayer' + DLLE.layerId).hasClass("visible")) {
            $('#displayedLayer' + DLLE.layerId).removeClass("visible");
            toggleLayer.find("span")
                .removeClass("glyphicon glyphicon-eye-open")
                .addClass("glyphicon glyphicon-eye-close");
            DLLE.layer.setVisible(false);
        }
        else {
            $('#displayedLayer' + DLLE.layerId).addClass("visible");
            toggleLayer.find("span")
                .removeClass("glyphicon glyphicon-eye-close")
                .addClass("glyphicon glyphicon-eye-open");
            DLLE.layer.setVisible(true);
        }
    });

    // Add a layer opacity slider
    var opacitySlider = $('<div class="opacity_slider"></div>');
    opacitySlider.slider({
        min: 0,
        max: 1,
        step: 0.1,
        value: 1,
        slide: function(event, ui) {
            DLLE.layer.setOpacity(ui.value);
        }
    });

    this.layerElement.find('div.btn-group').append(rmLayer, toggleLayer);
    this.layerElement.find('div.btn-group').after(opacitySlider);
}
