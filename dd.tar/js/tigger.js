
var map,
    defaultLayerOpacity = 1,
    availableLayers = {},
    availableLayersTitles = {};

$( document ).ready( function() {

  // Set projection
  var EPSGProjection = "EPSG:4326";
  var mapProjection = ol.proj.get(EPSGProjection);

  // Add map
  map = new ol.Map({
    controls: ol.control.defaults().extend([
      new ol.control.ScaleLine({
        units: 'degrees'
      })
    ]),
    target: 'map',
    view: new ol.View({
      projection: EPSGProjection,
      center: [0, 30],
      zoom: 4
    }),
    layers: [
      new ol.layer.Tile({
        source: new ol.source.Stamen({
          layer: 'toner-background'
        })
      })
    ]
  });

  // Sidebar
  var sidebar = new ol.control.Sidebar({ element: 'sidebar', position: 'left' });
  map.addControl(sidebar);

  // Set up sortable rows for the displayed layer list
  var moved_layer;
  $( "#sortable" ).sortable({
    axis: 'y',
    containment: 'parent',
    cursor: 'move',
    opacity: 0.75,
    start: function( event, ui ) {
      // Get original position
      var old_pos = map.getLayers().getLength() - ui.item.index() - 1; // Account for 1 base layer
      moved_layer = map.getLayers().removeAt( old_pos );
    },
    stop: function( event, ui ) {
      // Reorder the corresponding map layer appropriately
      var new_pos = map.getLayers().getLength() - ui.item.index(); // Account for 1 base layer
      map.getLayers().insertAt( new_pos, moved_layer );
    }
  });

  // Functionality to search available layers on input
  $( '#availableLayersSearch' ).on( 'input', function() {

    var layersToShow = Object.keys( availableLayersTitles );
    var layersToHide = [];

    for ( var layer_id in availableLayersTitles ) {
      if ( availableLayersTitles[layer_id]
             .toLowerCase()
             .indexOf( $(this).val().toLowerCase() )
             === -1 ) {
        layersToShow.splice( layersToShow.indexOf( layer_id ), 1 );
        layersToHide.push( layer_id );
      }
    }

    // Hide/show layers
    for ( var i=0; i<layersToShow.length; i++ ) {
      $( '#availableLayer' + layersToShow[i] ).css( 'display', 'inherit' );
    }
    for ( var i=0; i<layersToHide.length; i++ ) {
      $( '#availableLayer' + layersToHide[i] ).css( 'display', 'none' );
    }
  });

  // Set the maximum number of zoom levels.
  var maxZoomLevels = 6;

  // Set locations for endpoint and getCapabilities
//  var endpointURL = "./wmts.cgi?";
  var endpointURL = "https://gibs.earthdata.nasa.gov/wmts/epsg4326/best/wmts.cgi?";
//  var getCapabilities = "./getCapabilities.xml";
  var getCapabilities = "https://gibs.earthdata.nasa.gov/wmts/epsg4326/best/wmts.cgi?SERVICE=WMTS&request=GetCapabilities";

  // Get the WMTS capabilities, create layers and store them
  $.get( getCapabilities )
    .done( function( capabilities ) {

      //Use OpenLayers to parse getCapabilities
      var parser = new ol.format.WMTSCapabilities();
      var result = parser.read( capabilities );
      var layers = result.Contents.Layer;
      var tileMatrixSets = result.Contents.TileMatrixSet;
      var mapMetersPerUnit = mapProjection.getMetersPerUnit();

      for ( var i=0; i<layers.length; i++ ) {
        var tileMatrixSet,
            tileMatrixIds = [],
            resolutions = [];
        /*
        Ideally, this would use ol.source.WMTS.optionsFromCapabilities to
        generate the layer source from getCapabilites, but as of now, it only
        supports TileMatrixSets with names that correspond exactly to the 2
        projections it natively supports. So we have to parse the options and
        calculate the resolutions manually.
        */
        for ( var j=0; j<tileMatrixSets.length; j++ ) {
          if ( tileMatrixSets[j].Identifier == layers[i].TileMatrixSetLink[0].TileMatrixSet ) {
            tileMatrixSet = tileMatrixSets[j];
            for ( var k=0; k<tileMatrixSet.TileMatrix.length; k++ ) {
              tileMatrixIds.push( tileMatrixSet.TileMatrix[k].Identifier );
              resolutions.push( tileMatrixSet.TileMatrix[k].ScaleDenominator * 0.28E-3 /
                                mapMetersPerUnit );
            }
          }
        }

        var newLayerSource = new ol.source.WMTS({
          url: endpointURL,
          layer: layers[i].Identifier,
          format: layers[i].Format[0],
          matrixSet: layers[i].TileMatrixSetLink[0].TileMatrixSet,
          tileGrid: new ol.tilegrid.WMTS({
            origin: [tileMatrixSet.TileMatrix[0].TopLeftCorner[0],
                     tileMatrixSet.TileMatrix[0].TopLeftCorner[1]],
            matrixIds: tileMatrixIds,
            tileSize: tileMatrixSet.TileMatrix[0].TileHeight,
            resolutions: resolutions
          })
        });

        var newLayer = new ol.layer.Tile({
          source: newLayerSource,
          title: layers[i].Title,
        });

        availableLayers[layers[i].Identifier] = newLayer;
        availableLayersTitles[layers[i].Identifier] = layers[i].Title;
      }

      // Populate the available layers list
      for ( var layer_id in availableLayers ) {
        var LLE = new LayerListElement( layer_id, availableLayers[layer_id] );
        $('#availableLayersList').append( LLE.layerElement );
      }
    })
    .fail( function() {
      console.log( "Problems" );
    });

});

function LayerListElement( layer_id, layer ) {
  this.layer_id = layer_id;
  this.layer = layer;
  this.title = layer.getProperties().title;

  this.layerElement = $(
    '<a id="availableLayer' + this.layer_id +
    '" href="#" class="list-group-item list-group-item-action flex-column align-items-start">' +
    '<div class="d-flex w-100 justify-content-between">' +
    '<h5 class="mb-1">' + this.title + '</h5>' +
    '<small>' + this.layer_id + '</small>' +
    '</div>' +
    '</a>'
  );

  //  Functionality on mouse click
  var LLE = this;
  $( LLE.layerElement ).click( function() {
    if ( $( this ).hasClass( 'active' ) ) {
      $( this ).removeClass( 'active' );

      // Remove the layer from the map and displayed layer element
      map.removeLayer( LLE.layer );
       $('#displayedLayersList').find( '#displayedLayer' + LLE.layer_id ).parent().remove();

    }
    else {
      $( this ).addClass( 'active' );

      // Create an entry in the displayed layers list
      var DLLE = new DisplayedLayerListElement( LLE.layer_id, LLE.layer );
      $( '#displayedLayersList > ul' ).prepend( DLLE.layerElement );

      // Add the layer to the map
      map.addLayer( LLE.layer );
    }
  });
}

function DisplayedLayerListElement( layer_id, layer ) {
  this.layer_id = layer_id;
  this.layer = layer;
  this.title = layer.getProperties().title;

  this.layerElement = $(
    '<li class="ui-state-default">' +
    '<a id="displayedLayer' + this.layer_id +
    '" href="#" class="list-group-item list-group-item-action flex-column align-items-start visible">' +
    '<div class="d-flex w-100 justify-content-between">' +
    '<div class="btn-group" role="group">' +
    '</div>' +
    '<h5 class="mb-1">' + this.title + '</h5>' +
    '<small>' + this.layer_id + '</small>' +
    '</div>' +
    '</a>' +
    '</li>'
  );

  var DLLE = this;

  // Add a remove layer button
  var rmLayer = $(
    '<button class="btn btn-secondary" type="button"><span class="glyphicon glyphicon-remove"></span></button>'
  );
  rmLayer.click( function() {
    DLLE.layerElement.remove();
    $('#availableLayersList').find( '#availableLayer' + DLLE.layer_id ).removeClass( 'active' );
    map.removeLayer( DLLE.layer );
  });

  // Add a visiblity toggle button
  var toggleLayer = $(
    '<button class="btn btn-secondary" type="button"><span class="glyphicon glyphicon-eye-open"></span></button>'
  );
  toggleLayer.click( function() {
    if ( $('#displayedLayer' + DLLE.layer_id).hasClass( "visible" ) ) {
      $('#displayedLayer' + DLLE.layer_id).removeClass( "visible" );
      toggleLayer.find( "span" )
        .removeClass( "glyphicon glyphicon-eye-open" )
        .addClass( "glyphicon glyphicon-eye-close" );
      DLLE.layer.setVisible( false );
    }
    else {
      $('#displayedLayer' + DLLE.layer_id).addClass( "visible" );
      toggleLayer.find( "span" )
        .removeClass( "glyphicon glyphicon-eye-close" )
        .addClass( "glyphicon glyphicon-eye-open" );
      DLLE.layer.setVisible( true );
    }
  });

  // Add a layer opacity slider
  var $opacitySlider = $( '<div class="opacity_slider"></div>' );
  $opacitySlider.slider({
    min: 0,
    max: 1,
    step: 0.1,
    value: defaultLayerOpacity,
    slide: function( event, ui ) {
      DLLE.layer.setOpacity( ui.value );
    }
  });

  this.layerElement.find( 'div.btn-group' ).append( rmLayer, toggleLayer, $opacitySlider );
}
